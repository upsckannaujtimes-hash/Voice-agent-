import React from 'react';

interface VisualizerProps {
  volume: number; // 0 to 255 typically
  active: boolean;
}

export const Visualizer: React.FC<VisualizerProps> = ({ volume, active }) => {
  // Normalize volume to 0-1 range roughly
  const normalized = Math.min(1, volume / 100); 
  
  // Dynamic styling based on volume
  const scale = active ? 1 + normalized * 1.5 : 1;
  const opacity = active ? 0.6 + normalized * 0.4 : 0.3;
  const color = active ? '#3b82f6' : '#64748b'; // Blue-500 vs Slate-500

  return (
    <div className="relative flex items-center justify-center w-64 h-64">
      {/* Outer Glow */}
      <div 
        className="absolute rounded-full transition-all duration-75 ease-linear blur-xl"
        style={{
            width: '100%',
            height: '100%',
            backgroundColor: color,
            transform: `scale(${scale * 1.2})`,
            opacity: opacity * 0.5
        }}
      />
      
      {/* Core Circle */}
      <div 
        className="relative rounded-full transition-all duration-75 ease-linear shadow-lg"
        style={{
            width: '80%',
            height: '80%',
            backgroundColor: active ? '#1d4ed8' : '#334155', // Blue-700 vs Slate-700
            transform: `scale(${scale})`,
            border: `2px solid ${active ? '#93c5fd' : '#475569'}`
        }}
      >
        <div className="absolute inset-0 flex items-center justify-center">
            {active ? (
                 <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 text-white opacity-80" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
                </svg>
            ) : (
                <span className="text-slate-400 font-medium">Gemini</span>
            )}
        </div>
      </div>
      
      {/* Orbiting particles (Purely aesthetic) */}
      {active && (
         <div className="absolute inset-0 animate-spin-slow pointer-events-none">
            <div className="absolute top-0 left-1/2 w-3 h-3 bg-blue-300 rounded-full blur-sm transform -translate-x-1/2 -translate-y-4"></div>
         </div>
      )}
    </div>
  );
};