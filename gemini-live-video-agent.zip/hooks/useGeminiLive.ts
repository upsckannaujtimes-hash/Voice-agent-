import { useEffect, useRef, useState, useCallback } from 'react';
import { GoogleGenAI, LiveServerMessage, Modality } from '@google/genai';
import { ConnectionState, MessageLog } from '../types';
import { createPcmBlob, decodeAudioData, blobToBase64 } from '../utils/audioUtils';

// Configuration constants
const MODEL_NAME = 'gemini-2.5-flash-native-audio-preview-09-2025';
const INPUT_SAMPLE_RATE = 16000;
const OUTPUT_SAMPLE_RATE = 24000;
const VIDEO_FPS = 5;

export const useGeminiLive = () => {
  const [connectionState, setConnectionState] = useState<ConnectionState>(ConnectionState.DISCONNECTED);
  const [logs, setLogs] = useState<MessageLog[]>([]);
  const [volume, setVolume] = useState(0); // For visualizer (0-100)

  // Audio Contexts and Nodes
  const inputAudioContextRef = useRef<AudioContext | null>(null);
  const outputAudioContextRef = useRef<AudioContext | null>(null);
  const scriptProcessorRef = useRef<ScriptProcessorNode | null>(null);
  const sourceNodeRef = useRef<MediaStreamAudioSourceNode | null>(null);
  const gainNodeRef = useRef<GainNode | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);

  // Scheduling
  const nextStartTimeRef = useRef<number>(0);
  const audioSourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());
  
  // Interval for video frames
  const videoIntervalRef = useRef<number | null>(null);
  
  // API Session
  const sessionPromiseRef = useRef<Promise<any> | null>(null);
  const aiClientRef = useRef<GoogleGenAI | null>(null);

  const cleanup = useCallback(() => {
    // Stop video interval
    if (videoIntervalRef.current) {
      window.clearInterval(videoIntervalRef.current);
      videoIntervalRef.current = null;
    }

    // Stop all playing audio
    audioSourcesRef.current.forEach(source => {
      try { source.stop(); } catch (e) { /* ignore */ }
    });
    audioSourcesRef.current.clear();

    // Close audio contexts
    if (inputAudioContextRef.current) {
      inputAudioContextRef.current.close();
      inputAudioContextRef.current = null;
    }
    if (outputAudioContextRef.current) {
      outputAudioContextRef.current.close();
      outputAudioContextRef.current = null;
    }

    // Reset state
    setConnectionState(ConnectionState.DISCONNECTED);
    nextStartTimeRef.current = 0;
    sessionPromiseRef.current = null;
  }, []);

  const connect = useCallback(async (videoElement: HTMLVideoElement | null) => {
    try {
      setConnectionState(ConnectionState.CONNECTING);

      // 1. Init Client
      if (!process.env.API_KEY) {
        throw new Error("API Key not found in environment.");
      }
      aiClientRef.current = new GoogleGenAI({ apiKey: process.env.API_KEY });

      // 2. Init Audio Contexts
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      inputAudioContextRef.current = new AudioContextClass({ sampleRate: INPUT_SAMPLE_RATE });
      outputAudioContextRef.current = new AudioContextClass({ sampleRate: OUTPUT_SAMPLE_RATE });

      // Output Analyser for Visualizer
      analyserRef.current = outputAudioContextRef.current.createAnalyser();
      analyserRef.current.fftSize = 256;
      analyserRef.current.connect(outputAudioContextRef.current.destination);

      // 3. Get User Media (Mic)
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      
      // 4. Connect to Gemini Live
      sessionPromiseRef.current = aiClientRef.current.live.connect({
        model: MODEL_NAME,
        callbacks: {
          onopen: () => {
            console.log('Gemini Live Session Opened');
            setConnectionState(ConnectionState.CONNECTED);
            
            // Start Audio Streaming
            if (!inputAudioContextRef.current) return;
            
            const source = inputAudioContextRef.current.createMediaStreamSource(stream);
            const processor = inputAudioContextRef.current.createScriptProcessor(4096, 1, 1);
            
            processor.onaudioprocess = (e) => {
              const inputData = e.inputBuffer.getChannelData(0);
              const pcmBlob = createPcmBlob(inputData);
              
              sessionPromiseRef.current?.then(session => {
                session.sendRealtimeInput({ media: pcmBlob });
              }).catch(err => console.error("Session send error", err));
            };

            source.connect(processor);
            processor.connect(inputAudioContextRef.current.destination);
            
            sourceNodeRef.current = source;
            scriptProcessorRef.current = processor;

            // Start Video Streaming if available
            if (videoElement) {
              startVideoStreaming(videoElement);
            }
          },
          onmessage: async (msg: LiveServerMessage) => {
            // Handle Audio Output
            const base64Audio = msg.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data;
            if (base64Audio && outputAudioContextRef.current && analyserRef.current) {
              try {
                const audioCtx = outputAudioContextRef.current;
                const audioBuffer = await decodeAudioData(base64Audio, audioCtx);
                
                const source = audioCtx.createBufferSource();
                source.buffer = audioBuffer;
                source.connect(analyserRef.current); // Connect to visualizer/output
                
                // Scheduling
                // Ensure we don't schedule in the past
                const currentTime = audioCtx.currentTime;
                if (nextStartTimeRef.current < currentTime) {
                  nextStartTimeRef.current = currentTime;
                }
                
                source.start(nextStartTimeRef.current);
                nextStartTimeRef.current += audioBuffer.duration;
                
                source.onended = () => {
                  audioSourcesRef.current.delete(source);
                };
                audioSourcesRef.current.add(source);
              } catch (e) {
                console.error("Error decoding audio", e);
              }
            }

            // Handle Interruption
            if (msg.serverContent?.interrupted) {
              console.log("Model interrupted");
              audioSourcesRef.current.forEach(s => {
                try { s.stop(); } catch(e) {}
              });
              audioSourcesRef.current.clear();
              nextStartTimeRef.current = 0;
            }
            
            // Logging (Optional)
            if (msg.serverContent?.modelTurn?.parts?.[0]?.text) {
                 // Text is sometimes sent alongside audio or in tool use
                 const text = msg.serverContent.modelTurn.parts[0].text;
                 setLogs(prev => [...prev, { role: 'model', text, timestamp: new Date() }]);
            }
          },
          onclose: (e) => {
            console.log('Gemini Live Session Closed', e);
            cleanup();
          },
          onerror: (e) => {
            console.error('Gemini Live Session Error', e);
            setConnectionState(ConnectionState.ERROR);
            cleanup();
          }
        },
        config: {
          responseModalities: [Modality.AUDIO],
          systemInstruction: {
             parts: [{ text: "You are a helpful, witty, and concise AI video assistant. Keep your responses short and natural, suitable for a real-time voice conversation." }]
          }
        }
      });

    } catch (err) {
      console.error("Connection failed", err);
      setConnectionState(ConnectionState.ERROR);
      cleanup();
    }
  }, [cleanup]);

  const startVideoStreaming = (videoEl: HTMLVideoElement) => {
    if (videoIntervalRef.current) clearInterval(videoIntervalRef.current);

    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    
    videoIntervalRef.current = window.setInterval(async () => {
      if (!ctx || !videoEl || videoEl.paused || videoEl.ended) return;
      
      canvas.width = videoEl.videoWidth * 0.5; // Downscale for performance
      canvas.height = videoEl.videoHeight * 0.5;
      
      ctx.drawImage(videoEl, 0, 0, canvas.width, canvas.height);
      
      canvas.toBlob(async (blob) => {
        if (blob) {
          const base64 = await blobToBase64(blob);
          sessionPromiseRef.current?.then(session => {
             session.sendRealtimeInput({
               media: { mimeType: 'image/jpeg', data: base64 }
             });
          }).catch(() => {});
        }
      }, 'image/jpeg', 0.6); // Quality 0.6
      
    }, 1000 / VIDEO_FPS);
  };

  const disconnect = useCallback(() => {
    sessionPromiseRef.current?.then(session => session.close()); // This triggers onclose which does cleanup
    // Fallback cleanup in case close doesn't trigger immediately
    cleanup();
  }, [cleanup]);

  // Visualizer Loop
  useEffect(() => {
    if (connectionState !== ConnectionState.CONNECTED) return;
    
    let animId: number;
    const updateVolume = () => {
      if (analyserRef.current) {
        const dataArray = new Uint8Array(analyserRef.current.frequencyBinCount);
        analyserRef.current.getByteFrequencyData(dataArray);
        
        // Simple average volume
        let sum = 0;
        for (let i = 0; i < dataArray.length; i++) {
          sum += dataArray[i];
        }
        const avg = sum / dataArray.length;
        setVolume(avg);
      }
      animId = requestAnimationFrame(updateVolume);
    };
    updateVolume();
    
    return () => cancelAnimationFrame(animId);
  }, [connectionState]);

  return {
    connect,
    disconnect,
    connectionState,
    volume,
    logs
  };
};